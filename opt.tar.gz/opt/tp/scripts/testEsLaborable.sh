#!/bin/bash

#determina si una fecha ingresada por paramtero es dia laborable o no 

#utiliza esLaborable.sh

esLaborableScript="/opt/tp/scripts/esLaborable.sh"

#Valida si se paso un parametro

if [ $# -eq 1 ]; then
	fecha="$1"

	#verifica que el valor pasado sea una fecha valida
	if echo "$fecha" | grep -E "^2023-(0[1-9]1[0-2])-([0-2][1-9]|3[0-1])$" > /dev/null; then
		
		#verifiva si existe esLaborable.sh
		if [ -f"$esLaborableScript" ]; then
			result=$(bash "$esLaborableScript" "$fecha")
			echo "La fecha $fecha $result"
		else
			echo "El archivo esLaborable.sh no esta en la ruta especificada."
			exit 1
		fi
	else
		echo "Error. El formato de la fecha es incorrecto. Debe ser: YYYY-MM-DD."
		exit 1
	fi

else
	echo "Error. Debes pasar una fecha por parametro."
	echo "Uso: testEsLaborable <fecha>"
fi

