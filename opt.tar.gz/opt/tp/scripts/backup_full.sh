#!/bin/bash

#Generar log

generate_log(){
	echo "$(date + "%T") - $1" >> /var/log/backup.log
}


#enviar por mail log a root


send_log(){
	mutt -s "Backup log" -a /var/log/backup.log -- root < /dev/null
}

#validar directorios de origen y destino

validate_directories(){
	if ! test -d "$1"; then
		generate_log "no se encontro el directorio  de origen '$1'"
		return 1
	fi

	if ! test -d "$2"; then 
		generate_log "no se encontro el directorio de destino '$2'"
		return 1
	fi

	if ! df -P "$1" > /dev/null; then
		generate_log "el directorio de origen '$1' no esta montado"
		return 1
	fi

	if !  df -P "$2" > /dev/null; then
		generate_log "el directorio de destino '$2' no esta montado"
		return 1
	fi
}

#realizar backup

perform_backup(){
	local src_dir="$1"
	local dest_dir="$2"
	local base_dir=$(basename "$src_dir")
	local backup_file="${base_dir}_bkp_$(date +"%Y%m%d").tar.gz"

	tar -czf"$dest_dir/$backup_file" -C "$src_dir" .
	generate_log "backup realizado: $src_dir -> $dest_dir/$backup_file"
}

#procesar los parametros

process_arguments(){
	local src_dir="$1"
	local dest_dir="$2"

	validate_directories "$src_dir" "$dest_dir" || return 1
	perform_backup "$src_dir" "$dest_dir"
}

#procesar parametro ayuda 
process_help(){
	echo "invocation: backup_full.sh <directorio_origen> <directorio_destino>"
	echo "ejemplo: backup_full.sh /ruta/origen  /ruta/destino"
	echo "-h muestra esta ayuda"

}

main(){
	generate_log "ejecutando script backup_full.sh ..."

	if [[ $# -eq 2 ]]; then
		process_arguments "$1" "$2"
	elif [[ $# -eq 1 && $1 == "-h" ]]; then
		process_help
	else
		generate_log "parametros no validos"
		process_help
	fi

	generate_log "fin de ejecucion"
	send_log
}


main "$@"


