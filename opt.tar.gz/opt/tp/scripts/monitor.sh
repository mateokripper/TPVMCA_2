#!/bin/bash

#script para moniotorear procesos

#Verifica si se paso un parametro
if [ $# -eq 1 ]; then
	parametro="$1"
	proceso="pgrep -f $parametro"
	#Verifica si el proceso esta en ejecucion
	if ! $proceso >/dev/null; then
		echo "El proceso $parametro no esta en ejecucion." | mutt -s "Alerta de monitoreo de procesos" root@192.168.1.3
	fi
else 
	echo "Se debe pasar un proceso como argumento"
	exit 1
fi
