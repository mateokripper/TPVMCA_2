#!/bin/bash

#determina si la fecha es laborable

esLaborable(){
	
	fecha="$1"
#verificar si es fin de semana 
	if [ "$(date -d "$fecha" +%u)" -eq 6 ] || [ "$(date -d "$fecha" +%u)" -eq 7 ]; then
		echo "es fin de semana"
		return
	fi
#verifica si la fecha coincide con un dia no laborable

	case "$fecha" in
		#Enero
		"2023-01-01") echo "feriado: ano nuevo";;
		#Febrero
		"2023-02-20") echo "Feriado: Carnaval";;
		"2023-02-21") echo "Feriado: Carnvala";;
		#Marzo
		"2023-03-24") echo "Feriado: Dia Nacional de la Memoria por la Verdad y la Justicia";;
		#Abril
		"2023-04-02") echo "Feriado: Dia del veterano y de los caidos en la Guerra de Malvinas";;
		"2023-04-06") echo "Feriado: jueves santo";;
		"2023-04-07") echo "Feriado: viernes santo";;
		"2023-04-12") echo "Feriado: pascuas ";;
		"2023-04-13") echo "Feriado: pascuas ";;
		"2023-04-21") echo "Feriado: fiesta de la ruptura del ayuno del sagrado ramadan";;
		"2023-04-24") echo "Feriado: dia de accion por la tolerancia";;

		#Mayo 
		"2023-05-01") echo "Feriado: dia del trabajador";;
		"2023-05-25") echo "Feriado: dia de la revolucion de mayo";;
		"2023-05-26") echo "Feriado: puente turistico";;
		#Junio
		"2023-06-17") echo "Feriado: Guemes";;
		"2023-06-19") echo "Feriado: puente turistico";;
		"2023-06-20") echo "Feriado: Belgrano";;
		"2023-06-28") echo "Feriado: Fiesta del sacrificio";;
		#Julio
		"2023-07-09") echo "Feriado: Dia de la independencia";;
		"2023-07-19") echo "Feriado: Ano Nuevo Islamico";;
		#Agosto
		"2023-08-21") echo "Feriado: San Martin";;
		#Septiembre
		"2023-09-16") echo "Feriado: Ano Nuevo Judio";;
		"2023-09-17") echo "Feriado: Ano Nuevo Judio";;
		"2023-09-25") echo "Feriado: Dia del Perdon";;
		#Octube
		"2023-10-13") echo "Feriado: Puente Turistico";;
		"2023-10-16") echo "Feriado: Dia del Respeto a la Diversidad Cultural";;
		#Noviembre
		"2023-11-20") echo "Feriado: Dia de la Soberania Nacional";;
		#Diciembre
		"2023-12-08") echo "Feriado: Inmaculada Concepcion de Maria";;
		"2023-12-25") echo "Feriado: Navidad";;
		#Si es dia laborable
		*) echo "es dia laborable";;

 	esac
}

#LLama a la funcion si la fecha se paso como parametro
if [ $# -eq 1 ]; then
	esLaborable "$1"
fi
